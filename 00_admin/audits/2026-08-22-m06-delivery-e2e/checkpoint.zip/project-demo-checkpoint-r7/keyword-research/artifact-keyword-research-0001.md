released keyword-research artifact
