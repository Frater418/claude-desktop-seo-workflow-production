released strategy artifact
