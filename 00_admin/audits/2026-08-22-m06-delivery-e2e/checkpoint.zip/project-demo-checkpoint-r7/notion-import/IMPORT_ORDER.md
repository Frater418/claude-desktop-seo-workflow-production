# Manual Import Order

## Contract Resolution

`projects.csv` imports the customer row before the project row.

The approved Task 4 closed 14-file contract has no separate run, step, escalation, or command files. These remain Core-only in Sprint 5E.

## Import Sequence

1. `projects.csv`
2. `artifacts.csv`
3. `tasks.csv`
4. `assignments.csv`
5. `priorities.csv`
6. `deadlines.csv`
7. `reviews.csv`
8. `approvals.csv`
9. `blockers.csv`
10. `relations.csv`
11. `USER_MAPPING_TEMPLATE.csv`
12. `performance-checkpoints.csv`
13. `PROPERTY_MAPPING.md`
14. `IMPORT_ORDER.md`
