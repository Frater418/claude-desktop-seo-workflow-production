# Manual Import Mode

## Ownership Table

| Surface | Authority | Editable |
| --- | --- | --- |
| Core history and concept provenance | Core | no |
| Notion implementation task fields | Notion | yes |
| Step 3B scheduled checkpoints | Core after verified data | no |

## CSV Property Mappings

| CSV | Column | Notion property type | Authority/editability |
| --- | --- | --- | --- |
| projects.csv | record_type | Select | Core import classification, read-only |
| projects.csv | customer_external_id | Text | Core customer binding, read-only |
| projects.csv | external_id | Text | Core stable ID, read-only |
| projects.csv | tenant_id | Text | Core scope, read-only |
| projects.csv | project_id | Text | Core scope, read-only |
| projects.csv | source_sha256 | Text | Core provenance, read-only |
| tasks.csv | external_id | Text | Core stable ID, read-only |
| tasks.csv | tenant_id | Text | Core scope, read-only |
| tasks.csv | project_id | Text | Core scope, read-only |
| tasks.csv | task_class | Select | Core classification, read-only |
| tasks.csv | title | Title | Core history read-only; Notion implementation editable |
| tasks.csv | history_only | Checkbox | Core history marker, read-only |
| tasks.csv | status | Status | Notion implementation editable |
| tasks.csv | comments | Rich text | Notion implementation editable |
| tasks.csv | assignee | Person | Notion implementation editable |
| tasks.csv | priority | Select | Notion implementation editable |
| tasks.csv | deadline | Date | Notion implementation editable |
| tasks.csv | core_effect | Select | Core boundary marker, read-only |
| assignments.csv | external_id | Text | Core stable ID, read-only |
| assignments.csv | task_external_id | Relation to Tasks | Core task binding, read-only |
| assignments.csv | assignee | Person | Notion implementation editable |
| artifacts.csv | external_id | Text | Core stable ID, read-only |
| artifacts.csv | project_external_id | Relation to Projects | Core project binding, read-only |
| artifacts.csv | tenant_id | Text | Core scope, read-only |
| artifacts.csv | project_id | Text | Core scope, read-only |
| artifacts.csv | content_sha256 | Text | Core content provenance, read-only |
| artifacts.csv | revision | Number | Core revision, read-only |
| artifacts.csv | relative_path | Text | Core artifact location, read-only |
| artifacts.csv | role | Select | Core deliverable role, read-only |
| artifacts.csv | read_only | Checkbox | Core authority marker, read-only |
| reviews.csv | external_id | Text | Core stable ID, read-only |
| reviews.csv | project_external_id | Relation to Projects | Core project binding, read-only |
| reviews.csv | artifact_external_id | Relation to Artifacts | Core artifact binding, read-only |
| reviews.csv | source_sha256 | Text | Core provenance, read-only |
| reviews.csv | read_only | Checkbox | Core authority marker, read-only |
| approvals.csv | external_id | Text | Core canonical approval ID, read-only |
| approvals.csv | project_external_id | Relation to Projects | Core project binding, read-only |
| approvals.csv | artifact_external_id | Relation to Artifacts | Core release binding, read-only |
| approvals.csv | source_sha256 | Text | Core provenance, read-only |
| approvals.csv | read_only | Checkbox | Core authority marker, read-only |
| blockers.csv | external_id | Text | Core stable ID, read-only |
| blockers.csv | project_external_id | Relation to Projects | Core project binding, read-only |
| blockers.csv | artifact_external_id | Relation to Artifacts | Core artifact binding, read-only |
| blockers.csv | source_sha256 | Text | Core provenance, read-only |
| blockers.csv | read_only | Checkbox | Core authority marker, read-only |
| priorities.csv | task_external_id | Relation to Tasks | Core task binding, read-only |
| priorities.csv | value | Select | Notion implementation editable |
| deadlines.csv | task_external_id | Relation to Tasks | Core task binding, read-only |
| deadlines.csv | value | Date | Notion implementation editable |
| relations.csv | from_record_id | Relation | Core relation endpoint, read-only |
| relations.csv | to_record_id | Relation | Core relation endpoint, read-only |
| relations.csv | relation_type | Select | Core relation type, read-only |
| performance-checkpoints.csv | day_after_publication | Number | Core schedule, read-only |
| performance-checkpoints.csv | released_strategy_artifact_id | Relation to Artifacts | Core released strategy binding, read-only |
| performance-checkpoints.csv | released_plan_artifact_id | Relation to Artifacts | Core released plan binding, read-only |
| performance-checkpoints.csv | publication_registry_record_id | Text | Core publication binding, read-only |
| performance-checkpoints.csv | performance_data_status | Select | Core verified-data gate, read-only |
| USER_MAPPING_TEMPLATE.csv | assignment_external_id | Relation to Assignments | Core assignment binding, read-only |
| USER_MAPPING_TEMPLATE.csv | source_assignee | Rich text | Core source provenance, read-only |
| USER_MAPPING_TEMPLATE.csv | notion_user_id | Person | Manual Notion setup |

## Scheduled Performance Re-entry

Daily task completion cannot invoke Core. Only future scheduled Step 3B at days 30, 60, and 90 may re-enter Core with released strategy, released plan, publication registry, and verified performance data.
