released copywriter-handoff artifact
