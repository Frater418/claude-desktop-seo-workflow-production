# Copywriter Handoff

This index references canonical selected delivery artifacts.

| Step | Release state | Artifact | Path |
| --- | --- | --- | --- |
| 2 | released | artifact-keyword-research-0001 | [keyword-research/artifact-keyword-research-0001.md](../keyword-research/artifact-keyword-research-0001.md) |
| 3 | released | artifact-roadmap-0001 | [roadmap/artifact-roadmap-0001.md](../roadmap/artifact-roadmap-0001.md) |
| 4a | released | artifact-copywriter-handoff-0001 | [copywriter-handoff/artifact-copywriter-handoff-0001.md](artifact-copywriter-handoff-0001.md) |

## Review Requirements

| Review | Status | Requirements | Technical QA and Staging |
| --- | --- | --- | --- |
| review-delivery-0001 | required |  |  |

## Blockers

| Blocker | Status | Instructions |
| --- | --- | --- |
| blocker-delivery-0001 | open |  |
