released design artifact
